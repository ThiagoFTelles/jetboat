<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <h1 class="title">Embarcações</h1>
    <div class="field">
            <div class="control">
                <a class="button is-link" href="/vehicles/create">Adicionar Embarcação</a>
            </div>    
        </div>
    <div class="box">
        <ul>
            <?php $__currentLoopData = $vehicles->sortBy('owner_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="padding: 5px 0 5px 0;text-transform: uppercase;">
                <a href="/vehicles/<?php echo e($vehicle->uuid); ?>">
                   <h1 class="title is-6" style="color:#363636"> <?php echo e($vehicle->owner_name); ?> - <?php echo e($vehicle->model); ?> <?php if($vehicle->isDisused()): ?> <span style="color:red"> ! </span> <?php endif; ?></h1><?php echo $__env->make('vehicleStatus', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
        
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
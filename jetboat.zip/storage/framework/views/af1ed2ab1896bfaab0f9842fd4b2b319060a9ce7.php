<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h1 class="title">Embarcações fora da marina</h1>
    <div class="box">
        <ul>
            <?php $__currentLoopData = $vehicles->sortBy('owner_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($vehicle->status === 'out'): ?>
            <li style="padding: 5px 0 5px 0;text-transform: uppercase;">
                <a href="/vehicles/<?php echo e($vehicle->uuid); ?>">
                    <?php echo e($vehicle->owner_name); ?> - <?php echo e($vehicle->model); ?> <?php if($vehicle->isDisused()): ?> <span style="color:red"> ! </span> <?php endif; ?>
                </a>
            </li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
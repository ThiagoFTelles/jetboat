  <!-- Hero head: will stick at the top -->
  <div class="hero-head">
      <header class="navbar" style="background: white;">
          <div class="container">
              <div class="navbar-brand" style="width: inherit;">
                  <a class="navbar-item" href="/marina" style="background-color: white; flex-shrink: initial;display: contents;">
                      <img style="height: auto; min-width:90px"
                          src="https://lh3.googleusercontent.com/FF1B64RN1FHJzKOQO3Oww6qRUj1Dwft9atCMyrqnSDfc1JLKKdddcMytKalYqDHNvXf0nWgPst1-6VuEZuIClU5lvtaQ2nqEfnobO9WiJhvec1aQ8pSwOFcJCrjId1viCrgHSx_1wesAOVj-u-P-57RTqHoZYS_wLF7JffvNaWl02wePUsiRNxk-WLVMH2VjT90t60f0URow1balXR9nVl-zlJF9Ki6Z97nUgMITug3xsUq-nfP3yRiZWZAuk9gx3MfLc4yqTHNe4jNMrBQ9LSZu0yh9QCJBhOUlZEqWrlvfzRHDKMMALaRap746IcLKJry5_x8QI4JgQFRKd-ZM0djX62wwX0Rj4Nz3PFaHdsYgCINCyZ90A3qhCaVqk5ggLW_hBPbfbgBpEpeNw-j6ujvNzLUnFhqsHWGLCtcleACje1kZJcvQvYYciIo5wrMz7pYnECnNmE1toi8j4Q-PfDBc6NSwMxHfzfbPGMrWpOrp7iHJAcuDBJUW8aA70t-fPX4nEmbo8mq4AdNT0GzUDyEwXTJpbSxtCUkz6B-P4SvP8DxOt228ITRjitrR9Oyuoa0eSZBxd5R626M-f-xsx5BvI6pii7DlIA-zWak=w1600-h758"
                          alt="Marina Wave">
                  </a>
                  <a class="qr-icon" href="/qrcode" style="width: 35px;height: 35px;float: right">
                      <img style="width: 35px; height: 35px; max-width: unset;"
                          src="https://lh3.googleusercontent.com/1Le4AHprrR0jhx8k9i2WzjDIjvaLgz2dx0lK76OdqaVQecQJ70ntSrasC80wqrITNjYBRQe-S6Ry8uYl-5v6mD6KUbL9R190XXNzjWpHpAy-wBl0P8XTanesCj1kTXQRh3BUWJ4k9FSVIHH_UacW6dvaptc15TTZG2SdCkhOox9Gvlh-BL3U562F8up-YpgNRxuY_41F2EzpJIZccV11qNJytFzn2f7uxh7t4OE6oo69wVgOE-aCn2MV7lYO59ej44JycZFf99DVq_ARlugQNAjwFGs11gnj1AbM8V8dHOjW8zPtQtRIomFBY11D6Xb9SLGixjKwCvjux0bquuzgSJDuLgT5w3yHOJcLpwTtuoIgISNnDnA29zJo6Ew4gW9hVEQKA9qnVem6-Gv8wyokLOOrT02PBsZ9PpMGtDLqxySsr7pjngDknE6x6jHujYGvXaZIVQOTVqOCFjLyaIqUyjjzPOJaTqUyX3MLAnahPP1_LYhSFvL7rAo0yiKaZ0XPQznV1mXUzAkIG1W8_m2ieESkqUpnno0L6dtA_MOnA1wj-fGqdTlMh2CSpjPcTe5uHGyPafQP9mR7fGM9ORuAEtQr9y_BWXYA7wMEGCQ=w1600-h758"
                          alt="Marina Wave">
                  </a>
                  <span class="navbar-burger burger" data-target="navbarMenuHeroC" style="display:none;">
                      <span></span>
                      <span></span>
                      <span></span>
                  </span>
              </div>
          </div>
      </header>
  </div>
  <div style="
    width: 100%;background-color: white;">
      <div>
          <a class="navbar-item" href="/marina" style="float: left;color:grey;">Home</a>
          <a class="navbar-item" href="/report" style="float: left;color:grey;">Relatório</a>
          <a class="navbar-item" style="float: left;color:grey;" href="<?php echo e(route('logout'), false); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Logout'), false); ?></a>
        <form id="logout-form" action="<?php echo e(route('logout'), false); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
      </div>
  </div>
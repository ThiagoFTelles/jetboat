<?php if(session('message')): ?>
    <p><?php echo e(session('message')); ?></p>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('date-range', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="report">
    <script type="text/javascript">
        $(document).on('change', '.date', function hideReport(){
    $("#report").fadeOut();
        return false;
        });
    </script>

    <?php if($di): ?>
        <form id="export-report" method="POST" action="/export-report/?di=<?php echo e($di); ?> 00:00:00&df=<?php echo e($df); ?> 59:59:99">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('GET')); ?>

            <button style="width: auto;margin: 5px 0;"  class="button is-primary" type="submit">Baixar</button>
        </form>
    <?php endif; ?>

        <?php $__currentLoopData = $marinaActions->groupby('subject_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($action[0]['created_at'] <= $df): ?>
                <h4 style="padding: 5px 0 5px 0;text-transform: uppercase;">
                    <a href="/vehicles/<?php echo e($action[0]['properties']['attributes']['uuid']); ?>">
                        <h1 class="title is-6" style="color:#363636"> 
                            <?php echo e($action[0]['properties']['attributes']['owner_name']); ?>

                        </h1>
                        <?php $__currentLoopData = $vehicles->where('owner_name', $action[0]['properties']['attributes']['owner_name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('vehicleStatus', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </a>
                        <?php $__currentLoopData = $action; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul>
                                <li><?php echo e($a->created_at->format('d/m/Y H:i')); ?> - 
                                <?php switch($a->properties['attributes']['status']):
                                    case ('parked'): ?>
                                        estacionou
                                        <?php break; ?>
                                    <?php case ('navigating'): ?>
                                        navegou
                                        <?php break; ?>
                                    <?php case ('out'): ?>
                                        saiu
                                        <?php break; ?>
                                    <?php default: ?>
                                        movimentou
                                <?php endswitch; ?>
                                </li>
                            </ul>                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h4>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
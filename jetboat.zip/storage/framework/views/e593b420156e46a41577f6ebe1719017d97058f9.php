<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<h1 class="title">Cadastrar nova embarcação</h1>

<form method="POST" action="/vehicles">
    <?php echo e(csrf_field()); ?>

    <div class="box">
        <div class="field">
            <label class="label" for="name">Nome da Embarcação</label>
            <div class="control">
                <input type="text" class="input <?php echo e($errors -> has('name') ? 'is-danger' : ''); ?> " name="name" placeholder="Nome da Embarcação" value="<?php echo e(old('name')); ?>" required>
            </div>
        </div>

        <div class="field">

            <label class="label" for="owner_name">Proprietários</label>

            <div class="control">
                <input type="text" class="input <?php echo e($errors -> has('owner_name') ? 'is-danger' : ''); ?>" name="owner_name" placeholder="Dono ou donos" value="<?php echo e(old('owner_name')); ?>" required>
            </div>
        </div>

        <div class="field">

            <label class="label" for="brand">Marca</label>

            <div class="control">
                <input type="text" class="input <?php echo e($errors -> has('brand') ? 'is-danger' : ''); ?>" name="brand" placeholder="marca" value="<?php echo e(old('brand')); ?>" required>
            </div>
        </div>

        <div class="field">

            <label class="label" for="model">Modelo</label>

            <div class="control">
                <input type="text" class="input <?php echo e($errors -> has('model') ? 'is-danger' : ''); ?>" name="model" placeholder="modelo" value="<?php echo e(old('model')); ?>" required>
            </div>
        </div>

        <div class="field">

            <label class="label" for="year">Ano</label>

            <div class="control">
                <input type="text" class="input <?php echo e($errors -> has('year') ? 'is-danger' : ''); ?>" name="year" placeholder="ano" value="<?php echo e(old('year')); ?>" required>
            </div>
        </div>

        <div class="field">

            <label class="label" for="register_number">Registro</label>

            <div class="control">
                <input type="text" class="input <?php echo e($errors -> has('register_number') ? 'is-danger' : ''); ?>" name="register_number" placeholder="código de registro da embarcação" value="<?php echo e(old('register_number')); ?>" required>
            </div>
        </div>

        <div class="field">
            <label class="label" for="gas_percentage">Combustível (%)</label>
            <div class="control">
                <input type="number" min="0" max="100" step="5" class="input <?php echo e($errors -> has('gas_percentage') ? 'is-danger' : ''); ?>" name="gas_percentage" value="<?php echo e(old('gas_percentage')); ?>">
            </div>
        </div>

        <div class="field">
            <label class="label" for="navigation_hours">Horas</label>
            <div class="control">
                <input type="number" min="0" max="9999" class="input <?php echo e($errors -> has('navigation_hours') ? 'is-danger' : ''); ?>" name="navigation_hours" value="<?php echo e(old('navigation_hours')); ?>">
            </div>
        </div>

        <div class="field">
            <label class="label" for="belongings">Pertences</label>
            <div class="control">
                <input type="text" class="input <?php echo e($errors -> has('belongings') ? 'is-danger' : ''); ?>" name="belongings" value="<?php echo e(old('belongings')); ?>">
            </div>
        </div>

        <button class="button is-link" type="submit">Salvar</button>
    </div>
    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <p>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
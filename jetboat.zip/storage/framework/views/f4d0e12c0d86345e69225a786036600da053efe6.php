<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
    <h1 class="title is-3">FICHA TÉCNICA <?php echo e($vehicle->name); ?> <?php if($vehicle->isDisused()): ?> <span style="color:red"> ! </span> <?php endif; ?></h1>
    <h2 class="label" style="color: white;"><?php echo $__env->make('vehicleStatus', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></h2>
    
    <div class="content">
        <div class="field" >
            <label class="label" for="last_oil">Última troca de óleo</label>
            <input style="width: auto;margin: 5px 0;" class="input is-rounded date" type="date" id="last_oil" name="last_oil" data-date="" data-date-format="DD MMMM YYYY"/>
            <label class="label" for="next_oil">Próxima troca de óleo</label>
            <input style="width: auto;margin: 5px 0;" class="input is-rounded date" type="date" id="next_oil" name="next_oil" data-date="" data-date-format="DD MMMM YYYY"/>
            <label class="label" for="warranty">Garantia</label>
            <input style="width: auto;margin: 5px 0;" class="input is-rounded date" type="date" id="warranty" name="warranty" data-date="" data-date-format="DD MMMM YYYY"/>
        </div>
    </div>

    <div class="box">
        <h2 class="title">Manutenções</h2>
        <form id="add-maintenance" method="POST" action="/vehicles/<?php echo e($vehicle->uuid); ?>/add-maintenance"></form>
        <?php echo e(csrf_field()); ?>

        <button class="button is-primary" type="submit">
            <span class="icon has-text-info">
                <i class="fas fa-plus"></i>
                <i class="fas fa-tools"></i>
            </span>
        </button>

        <table>
            <thead>
                <tr>
                    <th>Descrição</th>
                    <th>Data prevista</th>
                    <th>Data realizada</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datasheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datasheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($datasheet->maintenance_description); ?></td> 
                        <td><?php echo e($datasheet->maintenance_expected_date->format('d/m/Y')); ?></td> 
                        <td><?php echo e($datasheet->maintenance_date_held->format('d/m/Y')); ?></td>          
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

    <div class="box">
        <h2 class="title">Reparos</h2>
        <form id="add-repair" method="POST" action="/vehicles/<?php echo e($vehicle->uuid); ?>/add-repair"></form>
        <?php echo e(csrf_field()); ?>

        <button class="button is-primary" type="submit">
            <span class="icon has-text-info">
                <i class="fas fa-plus"></i>
                <i class="fas fa-hammer"></i>
            </span>
        </button>

        <table>
            <thead>
                <tr>
                    <th>Data</th>
                    <th>Descrição</th>
                    <th>Mecânico</th>
                    <th>Contato</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datasheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datasheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($datasheet->repair_date_held->format('d/m/Y')); ?></td> 
                        <td><?php echo e($datasheet->repair_description); ?></td> 
                        <td><?php echo e($datasheet->repair_professional); ?></td>          
                        <td><?php echo e($datasheet->repair_professional_contact); ?></td>          
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
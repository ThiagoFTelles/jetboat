<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<h1 class="title"><?php echo e($vehicle->name); ?></h1>

<div class="box">
    <form action="/vehicles/<?php echo e($vehicle->uuid); ?>/action" method="POST" style="margin-bottom:1em">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="panel_info_container" style="text-align: left;">
            <p>Combustível: <input name="gas_percentage" style="width: 50px;text-align: center;" class="panel_info_input" id="gas_percentage" type="number" min="0" max="100" step="5" value="<?php echo e($vehicle->gas_percentage); ?>">%</p>

            <p>Horas: <input name="navigation_hours" style="width: 50px;text-align: center;" class="panel_info_input" id="navigation_hours" type="number" min="0" max="9999" value="<?php echo e($vehicle->navigation_hours); ?>"></p>

            <p>Pertences:</p>
            <textarea name="belongings" rows="4" cols="20" id="belongings" style="width: 100%;" class="panel_info_input"><?php echo e($vehicle->belongings); ?></textarea>
            <br>
            <br>
            <br>
        </div>
        <div class="field">
            <div class="control">
                <button class="button is-link" type="submit" name="action" value="parked">
                    Chegada
                </button>
                <p>Entrar na marina e estacionar embarcação</p><br>
                <button class="button is-link" type="submit" name="action" value="navigating">
                    Descer Rampa
                </button>
                <p>Sair para navegar</p><br>
                <button class="button is-link" type="submit" name="action" value="out">
                    Sair
                </button>
                <p>Sair temporariamente para viagem ou manutenção</p><br>
                <button class="button is-link" type="submit" name="action" value="run">
                    Funcionamento técnico
                </button>
                <p>Ligar o motor de uma embarcação a muito tempo parada</p><br>
                <button class="button is-link" type="submit" name="action" value="deleted">
                    Excluir
                </button>
                <p>Excluir embarcação desta marina</p>
            </div>
        </div>
    </form>


    <!-- <form action="/vehicles/<?php echo e($vehicle->uuid); ?>/generateqr/?text=<?php echo e($vehicle->uuid); ?>" method="POST" style="margin-bottom:1em">
            <?php echo csrf_field(); ?>
            <button class="button is-link" type="submit" name="value" value="<?php echo e($vehicle->uuid); ?>">
                        Gerar QrCode
            </button>

        </form> -->


    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<h1 class="title" style="margin: 0;"> <?php echo e($vehicle->name); ?> <?php if($vehicle->isDisused()): ?> <span style="color:red"> ! </span> <?php endif; ?></h1>
<h2 class="label" style="color: white;"><?php echo $__env->make('vehicleStatus', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></h2>
<div style="margin-bottom: 20px;">
    <p style="color: white;margin: 0;">Combustível: <?php echo e($vehicle->gas_percentage); ?>%</p>
    <p style="color: white;margin: 0;">Horas: <?php echo e($vehicle->navigation_hours); ?></p>
</div>

<div class="content">
    <a class="button is-link" href="/vehicles/<?php echo e($vehicle->uuid); ?>/action">Ação</a>
    <a class="button is-link" href="/vehicles/<?php echo e($vehicle->uuid); ?>/edit">Editar</a>
    <!-- <a class="button is-link" href="/vehicles/<?php echo e($vehicle->uuid); ?>/datasheets">Registros</a> -->
    <!-- Assim que terminar o sistema de Registros ("datasheets") coloco este link online  -->
    <a class="button is-link" target="_blank" href="/vehicles/<?php echo e($vehicle->uuid); ?>/generate-pdf">QrCode</a>
    <a class="button is-link" target="_blank" href="/vehicles/<?php echo e($vehicle->uuid); ?>/generate-mini-pdf">Mini QrCode</a>


</div>

<div class="box">
    <div class="field">
        <label class="label" for="owner_name">Proprietários</label>
        <div class="label">
            <h2><?php echo e($vehicle->owner_name); ?></h2>
        </div>
    </div>

    <div class="field">
        <label class="label" for="brand">Marca</label>
        <div class="label">
            <h2><?php echo e($vehicle->brand); ?></h2>
        </div>
    </div>

    <div class="field">
        <label class="label" for="model">Modelo</label>
        <div class="label">
            <h2><?php echo e($vehicle->model); ?></h2>
        </div>
    </div>

    <div class="field">
        <label class="label" for="year">Ano</label>
        <div class="label">
            <h2><?php echo e($vehicle->year); ?></h2>
        </div>
    </div>

    <div class="field">
        <label class="label" for="register_number">Registro</label>
        <div class="label">
            <h2><?php echo e($vehicle->register_number); ?></h2>
        </div>
    </div>

    <div class="field">
        <label class="label" for="register_number">Pertences</label>
        <div class="label">
            <p style="font-weight: 500;"><?php echo e($vehicle->belongings); ?></p>
        </div>
    </div>
</div>
<?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
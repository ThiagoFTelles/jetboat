<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<h1 class="title"><?php echo e($marina_name); ?></h1>
<?php if($disusedVehiclesAmount > 0): ?>

    <div class="notification is-danger">
        <a style="text-decoration:none;" href="/vehicles/disused">
            ATENÇÃO! <?php echo e($disusedVehiclesAmount); ?>     
    
    <?php switch($disusedVehiclesAmount):
        case (1): ?>
            embarcação
            <?php break; ?>
        <?php default: ?>
            embarcações
    <?php endswitch; ?> 
    
    paradas a mais de <?php echo e($DISUSED_DAYS); ?> dias. 
        </a>
    </div>

<?php endif; ?>

<a class="button box marina-home-link" href="/vehicles">
        <h1 class="subtitle is-5" style="color: maroon;font-size: 1.094rem;">Total: <?php echo e($totalVehiclesAmount); ?></h1>
</a>
<a class="button box marina-home-link" href="/vehicles/parked">
        <h1 class="subtitle is-5" style="color: maroon;font-size: 1.094rem;">Estacionados: <?php echo e($parkedVehiclesAmount); ?></h1>
</a>
<a class="button box marina-home-link" href="/vehicles/navigating">
        <h1 class="subtitle is-5" style="color: maroon;font-size: 1.094rem;">Navegando: <?php echo e($navigatingVehiclesAmount); ?></h1>
</a>
<a class="button box marina-home-link" href="/vehicles/out">
        <h1 class="subtitle is-5" style="color: maroon;font-size: 1.094rem;">Fora da Marina: <?php echo e($outingsVehiclesAmount); ?></h1>
</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
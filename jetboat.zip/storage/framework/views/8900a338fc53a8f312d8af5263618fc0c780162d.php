<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
    <h1 class="title"> <?php echo e($vehicle->name); ?> <?php if($vehicle->isDisused()): ?> <span style="color:red"> ! </span> <?php endif; ?></h1>
    <h2 class="label"><?php echo $__env->make('vehicleStatus', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></h2>
    
    <div id="qrcodegenerator">
        <qrcodegenerator></qrcodegenerator>
    </div>
    
    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
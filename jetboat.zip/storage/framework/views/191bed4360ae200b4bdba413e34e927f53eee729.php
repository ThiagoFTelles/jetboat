<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MarinaWave app</title>
</head>
<body>
    <?php $__currentLoopData = $marinaActions->groupby('subject_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($action[0]['created_at'] <= $df): ?>
                    <table>
                        <thead>
                            <tr>
                                <th><?php echo e($action[0]['properties']['attributes']['owner_name']); ?></th>
                                <th></th>
                                <th><?php echo e($action->count()); ?></th>
                            </tr>
                            <tr>
                                <th>Data</th>
                                <th>Hora</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $action; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($a->created_at->format('d/m/Y')); ?></td> 
                                    <td><?php echo e($a->created_at->format('H:i')); ?></td> 
                                    <td><?php switch($a->properties['attributes']['status']):
                                            case ('parked'): ?>
                                                estacionou
                                                <?php break; ?>
                                            <?php case ('navigating'): ?>
                                                navegou
                                                <?php break; ?>
                                            <?php case ('out'): ?>
                                                saiu
                                                <?php break; ?>
                                            <?php default: ?>
                                                movimentou
                                        <?php endswitch; ?>
                                    </td>          
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>

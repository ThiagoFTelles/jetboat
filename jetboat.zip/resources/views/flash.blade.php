@if (session('message'))
    <p>{{ session('message') }}</p>
@endif
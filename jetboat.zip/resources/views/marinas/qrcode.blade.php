@extends('layout')

@section('content')
<div id="qrcodereader">
    <qrcodereader></qrcodereader>
</div>
@endsection
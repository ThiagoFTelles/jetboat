@extends('layout')

@section('content')
@include ('flash')
@include ('errors')
@include ('date-range')

@endsection